<?php $__env->startSection('title', 'Product Data — ' . $cacheRecord->name); ?>
<?php $__env->startSection('page-title', 'Product Data'); ?>

<?php $__env->startSection('content'); ?>


<div class="flex items-center justify-between mb-5">
    <div class="flex items-center gap-3">
        <a href="<?php echo e(route('dashboard.product-cache.index')); ?>"
           class="text-gray-400 hover:text-gray-600 transition">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
            </svg>
        </a>
        <div>
            <h2 class="text-lg font-semibold text-gray-800"><?php echo e($cacheRecord->name); ?></h2>
            <p class="text-xs text-gray-400">
                Odoo ID: <?php echo e($cacheRecord->odoo_id); ?>

                <?php if($cacheRecord->default_code): ?> · SKU: <?php echo e($cacheRecord->default_code); ?> <?php endif; ?>
                · Fetched: <?php echo e($cacheRecord->fetched_at?->format('Y-m-d H:i:s')); ?>

            </p>
        </div>
    </div>

    <div class="flex items-center gap-2">
        
        <form method="POST" action="<?php echo e(route('dashboard.product-cache.refresh', $cacheRecord->odoo_id)); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit"
                    class="text-sm border border-gray-300 text-gray-600 hover:bg-gray-50 px-3 py-1.5 rounded-lg transition flex items-center gap-1.5">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                </svg>
                Re-fetch from Odoo
            </button>
        </form>

        
        <form method="POST" action="<?php echo e(route('dashboard.product-cache.post-shopify')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="ids[]" value="<?php echo e($cacheRecord->odoo_id); ?>">
            <button type="submit"
                    class="text-sm bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 rounded-lg transition flex items-center gap-1.5">
                Post Shopify
            </button>
        </form>

        
        <form method="POST" action="<?php echo e(route('dashboard.product-cache.post-amazon')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="ids[]" value="<?php echo e($cacheRecord->odoo_id); ?>">
            <button type="submit"
                    class="text-sm bg-orange-500 hover:bg-orange-600 text-white px-3 py-1.5 rounded-lg transition flex items-center gap-1.5">
                Post Amazon
            </button>
        </form>
    </div>
</div>


<div class="grid grid-cols-2 gap-3 mb-5">
    <div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center gap-3">
        <div class="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center shrink-0">
            <svg class="w-4 h-4 text-green-600" fill="currentColor" viewBox="0 0 24 24">
                <path d="M1.5 8.5c0-1.657 3.582-3 8-3s8 1.343 8 3v2c0 1.657-3.582 3-8 3s-8-1.343-8-3v-2z"/>
            </svg>
        </div>
        <div>
            <div class="text-xs text-gray-500">Shopify Status</div>
            <span class="badge <?php echo e($cacheRecord->statusBadgeClass('shopify')); ?> mt-0.5">
                <?php echo e(ucfirst($cacheRecord->shopify_status)); ?>

            </span>
            <?php if($cacheRecord->shopify_synced_at): ?>
            <div class="text-xs text-gray-400 mt-0.5"><?php echo e($cacheRecord->shopify_synced_at->format('Y-m-d H:i')); ?></div>
            <?php endif; ?>
            <?php if($cacheRecord->shopify_message): ?>
            <div class="text-xs text-red-500 mt-0.5"><?php echo e($cacheRecord->shopify_message); ?></div>
            <?php endif; ?>
        </div>
    </div>

    <div class="bg-white rounded-xl border border-gray-200 p-4 flex items-center gap-3">
        <div class="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center shrink-0">
            <svg class="w-4 h-4 text-orange-500" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/>
            </svg>
        </div>
        <div>
            <div class="text-xs text-gray-500">Amazon Status</div>
            <span class="badge <?php echo e($cacheRecord->statusBadgeClass('amazon')); ?> mt-0.5">
                <?php echo e(ucfirst($cacheRecord->amazon_status)); ?>

            </span>
            <?php if($cacheRecord->amazon_synced_at): ?>
            <div class="text-xs text-gray-400 mt-0.5"><?php echo e($cacheRecord->amazon_synced_at->format('Y-m-d H:i')); ?></div>
            <?php endif; ?>
            <?php if($cacheRecord->amazon_message): ?>
            <div class="text-xs text-red-500 mt-0.5"><?php echo e($cacheRecord->amazon_message); ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>


<?php if($data): ?>
<div class="space-y-4">

    
    <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div class="bg-gray-50 border-b border-gray-200 px-4 py-2.5 flex items-center justify-between">
            <h3 class="text-sm font-semibold text-gray-700">Product Template (Odoo)</h3>
            <span class="text-xs text-gray-400">product.template</span>
        </div>
        <div class="p-4">
            <table class="w-full text-sm">
                <?php $__currentLoopData = $data['template']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b border-gray-50 last:border-0">
                    <td class="py-1.5 pr-4 text-xs font-mono text-gray-400 w-48"><?php echo e($key); ?></td>
                    <td class="py-1.5 text-gray-700 break-all">
                        <?php if(is_array($value)): ?>
                            <span class="text-indigo-500"><?php echo e(json_encode($value)); ?></span>
                        <?php elseif(is_bool($value)): ?>
                            <span class="<?php echo e($value ? 'text-emerald-600' : 'text-red-500'); ?>"><?php echo e($value ? 'true' : 'false'); ?></span>
                        <?php elseif($value === null || $value === false): ?>
                            <span class="text-gray-300">null</span>
                        <?php else: ?>
                            <?php echo e($value); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>

    
    <?php if(!empty($data['variants'])): ?>
    <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div class="bg-gray-50 border-b border-gray-200 px-4 py-2.5 flex items-center justify-between">
            <h3 class="text-sm font-semibold text-gray-700">Variants (<?php echo e(count($data['variants'])); ?>)</h3>
            <span class="text-xs text-gray-400">product.product</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-xs">
                <thead>
                    <tr class="bg-gray-50 border-b border-gray-100">
                        <th class="px-3 py-2 text-left font-semibold text-gray-500">ID</th>
                        <th class="px-3 py-2 text-left font-semibold text-gray-500">Name</th>
                        <th class="px-3 py-2 text-left font-semibold text-gray-500">SKU</th>
                        <th class="px-3 py-2 text-left font-semibold text-gray-500">Barcode</th>
                        <th class="px-3 py-2 text-left font-semibold text-gray-500">Price</th>
                        <th class="px-3 py-2 text-left font-semibold text-gray-500">Weight</th>
                        <th class="px-3 py-2 text-left font-semibold text-gray-500">Attributes</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php $__currentLoopData = $data['variants']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-3 py-2 font-mono text-gray-500"><?php echo e($variant['id']); ?></td>
                        <td class="px-3 py-2 text-gray-700"><?php echo e($variant['name'] ?? '—'); ?></td>
                        <td class="px-3 py-2 font-mono text-indigo-600"><?php echo e($variant['default_code'] ?? '—'); ?></td>
                        <td class="px-3 py-2 font-mono text-gray-500"><?php echo e($variant['barcode'] ?? '—'); ?></td>
                        <td class="px-3 py-2 text-gray-700"><?php echo e($variant['lst_price'] ?? $variant['list_price'] ?? '—'); ?></td>
                        <td class="px-3 py-2 text-gray-500"><?php echo e($variant['weight'] ?? '—'); ?></td>
                        <td class="px-3 py-2 text-gray-500">
                            <?php echo e(json_encode($variant['product_template_attribute_value_ids'] ?? [])); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    
    <?php if(!empty($data['product_attributes'])): ?>
    <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div class="bg-gray-50 border-b border-gray-200 px-4 py-2.5">
            <h3 class="text-sm font-semibold text-gray-700">Product Attributes / Custom Fields</h3>
        </div>
        <div class="p-4">
            <table class="w-full text-sm">
                <?php $__currentLoopData = $data['product_attributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b border-gray-50 last:border-0">
                    <td class="py-1.5 pr-4 text-xs font-mono text-gray-400 w-48"><?php echo e($key); ?></td>
                    <td class="py-1.5 text-gray-700"><?php echo e(is_array($value) ? json_encode($value) : ($value ?? '—')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
    <?php endif; ?>

    
    <div class="bg-white rounded-xl border border-gray-200 overflow-hidden" x-data="{ show: false }">
        <div class="bg-gray-50 border-b border-gray-200 px-4 py-2.5 flex items-center justify-between">
            <h3 class="text-sm font-semibold text-gray-700">Raw JSON (full cache file)</h3>
            <button @click="show = !show" class="text-xs text-indigo-500 hover:text-indigo-700">
                <span x-text="show ? 'Hide' : 'Show'">Show</span>
            </button>
        </div>
        <div x-show="show" x-cloak class="p-4">
            <pre class="text-xs font-mono text-gray-600 bg-gray-50 rounded-lg p-4 overflow-x-auto max-h-96"><?php echo e(json_encode($data, JSON_PRETTY_PRINT)); ?></pre>
        </div>
    </div>
</div>
<?php else: ?>
<div class="bg-yellow-50 border border-yellow-200 rounded-xl p-6 text-center">
    <p class="text-sm text-yellow-700">Cache file not found on disk.</p>
    <form method="POST" action="<?php echo e(route('dashboard.product-cache.refresh', $cacheRecord->odoo_id)); ?>" class="mt-3">
        <?php echo csrf_field(); ?>
        <button type="submit" class="text-sm bg-yellow-600 text-white px-4 py-1.5 rounded-lg hover:bg-yellow-700">
            Re-fetch from Odoo
        </button>
    </form>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oddo\resources\views/dashboard/products/cache-detail.blade.php ENDPATH**/ ?>