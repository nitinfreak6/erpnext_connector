<?php $__env->startSection('title', 'Product Cache'); ?>
<?php $__env->startSection('page-title', 'Products Listing'); ?>

<?php $__env->startSection('content'); ?>
<div x-data="{ selected: [], selectAll: false }"
     x-on:change="selectAll ? selected = <?php echo e(json_encode($products->pluck('odoo_id')->toArray())); ?> : selected = []">


<div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
    <div class="bg-white rounded-xl border border-gray-200 p-4 text-center">
        <div class="text-2xl font-bold text-gray-800"><?php echo e($stats['total']); ?></div>
        <div class="text-xs text-gray-500 mt-0.5">Total Cached</div>
    </div>
    <div class="bg-white rounded-xl border border-gray-200 p-4 text-center">
        <div class="text-2xl font-bold text-emerald-600"><?php echo e($stats['shopify_sent']); ?></div>
        <div class="text-xs text-gray-500 mt-0.5">Shopify Sent</div>
    </div>
    <div class="bg-white rounded-xl border border-gray-200 p-4 text-center">
        <div class="text-2xl font-bold text-orange-500"><?php echo e($stats['amazon_sent']); ?></div>
        <div class="text-xs text-gray-500 mt-0.5">Amazon Sent</div>
    </div>
    <div class="bg-white rounded-xl border border-gray-200 p-4 text-center">
        <div class="text-2xl font-bold text-red-500"><?php echo e($stats['shopify_failed'] + $stats['amazon_failed']); ?></div>
        <div class="text-xs text-gray-500 mt-0.5">Failed</div>
    </div>
</div>


<div class="flex flex-wrap items-center justify-between gap-3 mb-4">
    
    <form method="GET" action="<?php echo e(route('dashboard.product-cache.index')); ?>"
          class="flex flex-wrap items-center gap-2">
        <input type="text" name="search" value="<?php echo e($search); ?>" placeholder="Search name / SKU..."
               class="text-sm border border-gray-300 rounded-lg px-3 py-1.5 focus:ring-2 focus:ring-indigo-300 outline-none w-48">

        <select name="shopify" class="text-sm border border-gray-300 rounded-lg px-3 py-1.5 outline-none">
            <option value="">Shopify: All</option>
            <option value="pending" <?php echo e($shopifyFilter==='pending' ? 'selected' : ''); ?>>Pending</option>
            <option value="sent"    <?php echo e($shopifyFilter==='sent'    ? 'selected' : ''); ?>>Sent</option>
            <option value="failed"  <?php echo e($shopifyFilter==='failed'  ? 'selected' : ''); ?>>Failed</option>
        </select>

        <select name="amazon" class="text-sm border border-gray-300 rounded-lg px-3 py-1.5 outline-none">
            <option value="">Amazon: All</option>
            <option value="pending" <?php echo e($amazonFilter==='pending' ? 'selected' : ''); ?>>Pending</option>
            <option value="sent"    <?php echo e($amazonFilter==='sent'    ? 'selected' : ''); ?>>Sent</option>
            <option value="failed"  <?php echo e($amazonFilter==='failed'  ? 'selected' : ''); ?>>Failed</option>
        </select>

        <button type="submit" class="text-sm bg-gray-800 text-white px-3 py-1.5 rounded-lg">Filter</button>
        <a href="<?php echo e(route('dashboard.product-cache.index')); ?>" class="text-sm text-gray-400 hover:text-gray-600">Clear</a>
    </form>

    
    <div class="flex flex-wrap items-center gap-2">

        
        <form method="POST" action="<?php echo e(route('dashboard.product-cache.fetch')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit"
                    class="inline-flex items-center gap-1.5 text-sm bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded-lg transition">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                </svg>
                Fetch Products
            </button>
        </form>

        
        <form method="POST" action="<?php echo e(route('dashboard.product-cache.post-shopify')); ?>" id="shopifyForm">
            <?php echo csrf_field(); ?>
            <template x-for="id in selected">
                <input type="hidden" name="ids[]" :value="id">
            </template>
            <button type="submit"
                    class="inline-flex items-center gap-1.5 text-sm bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 rounded-lg transition">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l4-4m0 0l4 4m-4-4v12"/>
                </svg>
                Post Shopify
                <span x-show="selected.length > 0" class="bg-white text-green-700 rounded-full px-1.5 text-xs font-bold"
                      x-text="selected.length"></span>
            </button>
        </form>

        
        <form method="POST" action="<?php echo e(route('dashboard.product-cache.post-amazon')); ?>" id="amazonForm">
            <?php echo csrf_field(); ?>
            <template x-for="id in selected">
                <input type="hidden" name="ids[]" :value="id">
            </template>
            <button type="submit"
                    class="inline-flex items-center gap-1.5 text-sm bg-orange-500 hover:bg-orange-600 text-white px-3 py-1.5 rounded-lg transition">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l4-4m0 0l4 4m-4-4v12"/>
                </svg>
                Post Amazon
                <span x-show="selected.length > 0" class="bg-white text-orange-600 rounded-full px-1.5 text-xs font-bold"
                      x-text="selected.length"></span>
            </button>
        </form>

        
        <form method="POST" action="<?php echo e(route('dashboard.product-cache.clear-all')); ?>"
              onsubmit="return confirm('Clear ALL cached products?')">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button type="submit"
                    class="text-sm border border-gray-300 text-gray-500 hover:bg-gray-50 px-3 py-1.5 rounded-lg transition">
                Clear Cache
            </button>
        </form>
    </div>
</div>


<div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
    <?php if($products->isEmpty()): ?>
        <div class="py-16 text-center">
            <svg class="w-10 h-10 text-gray-300 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                      d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
            </svg>
            <p class="text-sm text-gray-400 font-medium">No products cached yet</p>
            <p class="text-xs text-gray-300 mt-1">Click "Fetch Products" to pull from Odoo</p>
        </div>
    <?php else: ?>
    <table class="w-full text-sm">
        <thead>
            <tr class="bg-gray-50 border-b border-gray-200 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                <th class="px-4 py-3 w-8">
                    <input type="checkbox" x-model="selectAll"
                           class="rounded text-indigo-600 cursor-pointer">
                </th>
                <th class="px-4 py-3 text-left">#</th>
                <th class="px-4 py-3 text-left">Odoo ID</th>
                <th class="px-4 py-3 text-left">Product Name</th>
                <th class="px-4 py-3 text-left">SKU</th>
                <th class="px-4 py-3 text-left">Shopify</th>
                <th class="px-4 py-3 text-left">Amazon</th>
                <th class="px-4 py-3 text-left">Fetched At</th>
                <th class="px-4 py-3 text-right">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="hover:bg-gray-50 transition">
                
                <td class="px-4 py-3">
                    <input type="checkbox" :value="<?php echo e($product->odoo_id); ?>" x-model="selected"
                           class="rounded text-indigo-600 cursor-pointer">
                </td>

                
                <td class="px-4 py-3 text-gray-400 text-xs"><?php echo e($products->firstItem() + $i); ?></td>

                
                <td class="px-4 py-3 font-mono text-xs text-gray-600"><?php echo e($product->odoo_id); ?></td>

                
                <td class="px-4 py-3">
                    <div class="font-medium text-gray-800"><?php echo e($product->name); ?></div>
                </td>

                
                <td class="px-4 py-3 font-mono text-xs text-gray-500">
                    <?php echo e($product->default_code ?: '—'); ?>

                </td>

                
                <td class="px-4 py-3">
                    <div class="flex flex-col gap-1">
                        <span class="badge <?php echo e($product->statusBadgeClass('shopify')); ?>">
                            <?php echo e(ucfirst($product->shopify_status)); ?>

                        </span>
                        <?php if($product->shopify_message): ?>
                        <span class="text-xs text-red-500 truncate max-w-24" title="<?php echo e($product->shopify_message); ?>">
                            <?php echo e(Str::limit($product->shopify_message, 30)); ?>

                        </span>
                        <?php endif; ?>
                    </div>
                </td>

                
                <td class="px-4 py-3">
                    <div class="flex flex-col gap-1">
                        <span class="badge <?php echo e($product->statusBadgeClass('amazon')); ?>">
                            <?php echo e(ucfirst($product->amazon_status)); ?>

                        </span>
                        <?php if($product->amazon_message): ?>
                        <span class="text-xs text-red-500 truncate max-w-24" title="<?php echo e($product->amazon_message); ?>">
                            <?php echo e(Str::limit($product->amazon_message, 30)); ?>

                        </span>
                        <?php endif; ?>
                    </div>
                </td>

                
                <td class="px-4 py-3 text-xs text-gray-400">
                    <?php echo e($product->fetched_at?->format('Y-m-d H:i') ?? '—'); ?>

                </td>

                
                <td class="px-4 py-3 text-right">
                    <div class="flex items-center justify-end gap-1">
                        
                        <a href="<?php echo e(route('dashboard.product-cache.show', $product->odoo_id)); ?>"
                           class="text-indigo-500 hover:text-indigo-700 p-1 rounded hover:bg-indigo-50 transition" title="View Odoo Data">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                      d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                      d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                            </svg>
                        </a>

                        
                        <form method="POST" action="<?php echo e(route('dashboard.product-cache.refresh', $product->odoo_id)); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                    class="text-gray-400 hover:text-gray-700 p-1 rounded hover:bg-gray-100 transition" title="Refresh from Odoo">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                          d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                                </svg>
                            </button>
                        </form>

                        
                        <form method="POST" action="<?php echo e(route('dashboard.product-cache.clear', $product->odoo_id)); ?>"
                              onsubmit="return confirm('Clear cache for this product?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                    class="text-red-400 hover:text-red-600 p-1 rounded hover:bg-red-50 transition" title="Clear Cache">
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                          d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                </svg>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php if($products->hasPages()): ?>
    <div class="px-4 py-3 border-t border-gray-100 flex items-center justify-between">
        <p class="text-xs text-gray-500">
            Showing <?php echo e($products->firstItem()); ?>–<?php echo e($products->lastItem()); ?> of <?php echo e($products->total()); ?>

        </p>
        <?php echo e($products->links()); ?>

    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oddo\resources\views/dashboard/products/cache.blade.php ENDPATH**/ ?>