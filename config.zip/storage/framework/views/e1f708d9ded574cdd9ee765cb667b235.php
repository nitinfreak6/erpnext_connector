<?php $__env->startSection('title', 'Inventory'); ?>
<?php $__env->startSection('page-title', 'Inventory Sync'); ?>

<?php $__env->startSection('content'); ?>


<div class="grid grid-cols-3 gap-4 mb-4">
    <?php $__currentLoopData = [
        ['label' => 'Total SKUs',       'value' => $stats['total_skus'],   'color' => 'indigo'],
        ['label' => 'Mapped SKUs',      'value' => $stats['mapped_skus'] ?? 0, 'color' => 'violet'],
        ['label' => 'Synced Today',     'value' => $stats['synced_today'], 'color' => 'green'],
        ['label' => 'Failed Today',     'value' => $stats['failed_today'], 'color' => 'red'],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4 flex items-center gap-3">
        <div class="text-2xl font-bold text-<?php echo e($s['color']); ?>-600"><?php echo e(number_format($s['value'])); ?></div>
        <div class="text-sm text-gray-500"><?php echo e($s['label']); ?></div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="grid grid-cols-2 gap-4 mb-4">
    <?php $__currentLoopData = $syncState; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
        <div class="flex items-center justify-between">
            <span class="text-sm font-medium text-gray-700 capitalize"><?php echo e(str_replace('_', ' ', $key)); ?></span>
            <?php if($state->is_running): ?>
                <span class="badge bg-blue-100 text-blue-700 animate-pulse">● Running</span>
            <?php else: ?>
                <span class="badge bg-gray-100 text-gray-600">Idle</span>
            <?php endif; ?>
        </div>
        <div class="text-xs text-gray-500 mt-2">
            Last poll: <span class="font-medium text-gray-700"><?php echo e($state->last_poll_at?->diffForHumans() ?? 'Never'); ?></span>
        </div>
        <?php if($state->last_odoo_write_date): ?>
        <div class="text-xs text-gray-400 mt-0.5">Cursor: <?php echo e($state->last_odoo_write_date); ?></div>
        <?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden mb-4">
    <div class="px-5 py-3 border-b border-gray-100 flex items-center justify-between">
        <span class="text-sm font-medium text-gray-700"><?php echo e($variants->total()); ?> SKU mappings</span>
        <form method="GET" class="flex gap-2">
            <input type="text" name="search" value="<?php echo e($search); ?>"
                   placeholder="SKU, Odoo ID…"
                   class="border border-gray-200 rounded-lg px-3 py-1 text-xs w-48 focus:ring-2 focus:ring-indigo-300 outline-none">
            <button class="text-xs bg-indigo-600 text-white px-3 py-1 rounded-lg hover:bg-indigo-700">Search</button>
        </form>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wide">
                <tr>
                    <th class="px-4 py-3 text-left font-medium">SKU (Odoo Ref)</th>
                    <th class="px-4 py-3 text-left font-medium">Odoo Variant ID</th>
                    <th class="px-4 py-3 text-left font-medium">Shopify Variant ID</th>
                    <th class="px-4 py-3 text-left font-medium">Shopify Inventory Item ID</th>
                    <th class="px-4 py-3 text-left font-medium">Last Synced</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php $__empty_1 = true; $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3 font-mono text-xs font-medium text-gray-800"><?php echo e($v->odoo_reference ?: '—'); ?></td>
                    <td class="px-4 py-3 font-mono text-xs text-gray-600">
                        <span class="bg-gray-100 px-1.5 py-0.5 rounded">#<?php echo e($v->odoo_id); ?></span>
                    </td>
                    <td class="px-4 py-3 font-mono text-xs text-indigo-600"><?php echo e($v->shopify_id); ?></td>
                    <td class="px-4 py-3 font-mono text-xs text-gray-500"><?php echo e($v->shopify_secondary_id ?: '—'); ?></td>
                    <td class="px-4 py-3 text-xs text-gray-400"><?php echo e($v->last_synced_at?->diffForHumans() ?? 'Never'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="px-4 py-12 text-center text-gray-400">
                        No variant mappings with Shopify inventory item IDs.
                        <div class="text-xs text-gray-400 mt-2">
                            Run <span class="font-mono bg-gray-100 px-1.5 py-0.5 rounded">php artisan sync:products --full</span>
                            and ensure Shopify variant SKUs match Odoo <span class="font-mono">default_code</span>.
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="px-5 py-3 border-t border-gray-100"><?php echo e($variants->links()); ?></div>
</div>


<div class="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
    <h3 class="text-sm font-semibold text-gray-700 mb-3">Recent Inventory Sync Logs</h3>
    <?php echo $__env->make('dashboard._log-rows', ['logs' => $recentLogs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oddo\resources\views/dashboard/inventory.blade.php ENDPATH**/ ?>