<?php $__env->startSection('title', 'Log Detail'); ?>
<?php $__env->startSection('page-title', 'Sync Log Detail'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl">
    <div class="mb-4">
        <a href="<?php echo e(route('dashboard.logs')); ?>" class="text-sm text-indigo-600 hover:underline">← Back to logs</a>
    </div>

    <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-6 space-y-6">

        
        <div class="flex items-start justify-between">
            <div>
                <div class="flex items-center gap-2 mb-1">
                    <span class="badge bg-gray-100 text-gray-700"><?php echo e($log->entity_type); ?></span>
                    <span class="font-mono text-sm text-gray-700">#<?php echo e($log->entity_id); ?></span>
                    <?php $colors = ['success'=>'green','failed'=>'red','pending'=>'yellow','processing'=>'blue','skipped'=>'gray']; $c = $colors[$log->status] ?? 'gray'; ?>
                    <span class="badge bg-<?php echo e($c); ?>-100 text-<?php echo e($c); ?>-700"><?php echo e($log->status); ?></span>
                </div>
                <p class="text-xs text-gray-400"><?php echo e($log->created_at->format('Y-m-d H:i:s')); ?></p>
            </div>
            <div class="text-right text-sm text-gray-500">
                <div>Attempts: <strong><?php echo e($log->attempts); ?></strong></div>
                <div>Action: <strong><?php echo e($log->action); ?></strong></div>
            </div>
        </div>

        
        <?php if($log->error_message): ?>
        <div class="bg-red-50 border border-red-200 rounded-lg p-4">
            <h4 class="text-sm font-semibold text-red-700 mb-1">Error</h4>
            <p class="text-sm text-red-600"><?php echo e($log->error_message); ?></p>
        </div>
        <?php endif; ?>

        
        <?php if($log->error_context): ?>
        <div>
            <h4 class="text-sm font-semibold text-gray-700 mb-2">Error Context</h4>
            <pre class="bg-gray-50 border border-gray-200 rounded-lg p-4 text-xs text-gray-700 overflow-x-auto whitespace-pre-wrap"><?php echo e(json_encode($log->error_context, JSON_PRETTY_PRINT)); ?></pre>
        </div>
        <?php endif; ?>

        
        <?php if($log->request_payload): ?>
        <div>
            <h4 class="text-sm font-semibold text-gray-700 mb-2">Request Payload</h4>
            <pre class="bg-gray-50 border border-gray-200 rounded-lg p-4 text-xs text-gray-700 overflow-x-auto whitespace-pre-wrap max-h-96"><?php echo e(json_encode(json_decode($log->request_payload), JSON_PRETTY_PRINT) ?: $log->request_payload); ?></pre>
        </div>
        <?php endif; ?>

        
        <?php if($log->response_payload): ?>
        <div>
            <h4 class="text-sm font-semibold text-gray-700 mb-2">Response Payload</h4>
            <pre class="bg-gray-50 border border-gray-200 rounded-lg p-4 text-xs text-gray-700 overflow-x-auto whitespace-pre-wrap max-h-96"><?php echo e(json_encode(json_decode($log->response_payload), JSON_PRETTY_PRINT) ?: $log->response_payload); ?></pre>
        </div>
        <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oddo\resources\views/dashboard/log-detail.blade.php ENDPATH**/ ?>