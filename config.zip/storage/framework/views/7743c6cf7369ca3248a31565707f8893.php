
<div class="overflow-x-auto">
    <table class="w-full text-sm">
        <thead class="text-xs text-gray-500 border-b border-gray-100">
            <tr>
                <th class="text-left pb-2 font-medium">Direction</th>
                <th class="text-left pb-2 font-medium">Entity</th>
                <th class="text-left pb-2 font-medium">ID</th>
                <th class="text-left pb-2 font-medium">Action</th>
                <th class="text-left pb-2 font-medium">Status</th>
                <th class="text-left pb-2 font-medium">Error</th>
                <th class="text-left pb-2 font-medium">When</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-50">
            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="hover:bg-gray-50">
                <td class="py-2">
                    <?php if($log->direction === 'odoo_to_shopify'): ?>
                        <span class="badge bg-blue-100 text-blue-700">Odoo → Shop</span>
                    <?php else: ?>
                        <span class="badge bg-purple-100 text-purple-700">Shop → Odoo</span>
                    <?php endif; ?>
                </td>
                <td class="py-2"><span class="badge bg-gray-100 text-gray-600"><?php echo e($log->entity_type); ?></span></td>
                <td class="py-2 font-mono text-xs text-gray-600">#<?php echo e($log->entity_id); ?></td>
                <td class="py-2 text-gray-600 capitalize"><?php echo e($log->action); ?></td>
                <td class="py-2">
                    <?php $colors = ['success'=>'green','failed'=>'red','pending'=>'yellow','processing'=>'blue','skipped'=>'gray']; $c = $colors[$log->status] ?? 'gray'; ?>
                    <span class="badge bg-<?php echo e($c); ?>-100 text-<?php echo e($c); ?>-700"><?php echo e($log->status); ?></span>
                </td>
                <td class="py-2 text-xs text-red-500 max-w-xs truncate">
                    <?php echo e(Str::limit($log->error_message, 50)); ?>

                </td>
                <td class="py-2 text-xs text-gray-400"><?php echo e($log->created_at->diffForHumans()); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="7" class="py-6 text-center text-gray-400">No logs yet</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\oddo\resources\views/dashboard/_log-rows.blade.php ENDPATH**/ ?>