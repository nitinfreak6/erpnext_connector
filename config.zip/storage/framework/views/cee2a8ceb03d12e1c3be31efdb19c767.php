<?php $__env->startSection('title', 'API Settings'); ?>
<?php $__env->startSection('page-title', 'API Settings'); ?>

<?php $__env->startSection('content'); ?>

<div x-data="{ activeTab: '<?php echo e($groups->keys()->first()); ?>' }">

    
    <div class="flex gap-1 mb-6 bg-white rounded-xl border border-gray-100 shadow-sm p-1 w-fit">
        <?php $__currentLoopData = $groups->keys(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button @click="activeTab = '<?php echo e($group); ?>'"
                :class="activeTab === '<?php echo e($group); ?>' ? 'bg-indigo-600 text-white shadow' : 'text-gray-500 hover:text-gray-700'"
                class="px-4 py-2 rounded-lg text-sm font-medium transition capitalize">
            <?php echo e($group); ?>

        </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $settings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div x-show="activeTab === '<?php echo e($group); ?>'" x-cloak>
        <form method="POST" action="<?php echo e(route('dashboard.settings.update')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="hidden" name="group" value="<?php echo e($group); ?>">

            <div class="bg-white rounded-xl border border-gray-100 shadow-sm divide-y divide-gray-50">

                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="px-6 py-5 grid grid-cols-3 gap-6 items-start">
                    <div>
                        <label class="block text-sm font-medium text-gray-800"><?php echo e($setting->label); ?></label>
                        <?php if($setting->description): ?>
                        <p class="text-xs text-gray-400 mt-1"><?php echo e($setting->description); ?></p>
                        <?php endif; ?>
                        <?php if($setting->is_secret): ?>
                        <span class="badge bg-red-100 text-red-700 text-xs mt-2">Secret</span>
                        <?php endif; ?>
                    </div>
                    <div class="col-span-2">
                        <?php if($setting->is_secret): ?>
                        
                        <div class="flex gap-2" x-data="{ revealed: false, loading: false, val: '' }">
                            <div class="flex-1 relative">
                                <input :type="revealed ? 'text' : 'password'"
                                       name="<?php echo e($setting->key); ?>"
                                       :value="revealed ? val : ''"
                                       :placeholder="revealed ? '' : '<?php echo e($setting->getMaskedValue() ?: 'Not set'); ?>'"
                                       class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm font-mono focus:ring-2 focus:ring-indigo-300 outline-none">
                            </div>
                            <?php if(auth()->user()->can('reveal-secrets')): ?>
                            <button type="button"
                                    @click="loading = true; fetch('<?php echo e(route('dashboard.settings.reveal', $setting)); ?>', {headers:{'X-Requested-With':'XMLHttpRequest','Accept':'application/json'}}).then(r=>r.json()).then(d=>{val=d.value;revealed=true;loading=false}).catch(()=>loading=false)"
                                    :disabled="revealed || loading"
                                    class="px-3 py-2 text-xs border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap transition">
                                <span x-show="!loading && !revealed">Reveal</span>
                                <span x-show="loading">…</span>
                                <span x-show="revealed && !loading">Shown</span>
                            </button>
                            <?php endif; ?>
                        </div>
                        <p class="text-xs text-gray-400 mt-1">Leave blank to keep existing value.</p>
                        <?php else: ?>
                        <input type="text"
                               name="<?php echo e($setting->key); ?>"
                               value="<?php echo e($setting->getDecryptedValue() ?? $setting->default_value); ?>"
                               placeholder="<?php echo e($setting->default_value); ?>"
                               class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-300 outline-none">
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="px-6 py-4 bg-gray-50 flex justify-end">
                    <button type="submit"
                            class="bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium px-5 py-2 rounded-lg transition">
                        Save <?php echo e(ucfirst($group)); ?> Settings
                    </button>
                </div>
            </div>
        </form>

        
        <?php if($group === 'general' && auth()->user()->can('trigger-sync')): ?>
        <div class="mt-6 bg-white rounded-xl border border-gray-100 shadow-sm p-6">
            <h3 class="text-sm font-semibold text-gray-700 mb-4">Manual Sync Triggers</h3>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
                <?php $__currentLoopData = [
                    'products'         => ['label' => 'Shopify Products', 'color' => 'indigo'],
                    'inventory'        => ['label' => 'Shopify Inventory', 'color' => 'indigo'],
                    'orders'           => ['label' => 'Shopify Orders',   'color' => 'indigo'],
                    'customers'        => ['label' => 'Customers',        'color' => 'indigo'],
                    'amazon_products'  => ['label' => 'Amazon Products',  'color' => 'amber'],
                    'amazon_orders'    => ['label' => 'Amazon Orders',    'color' => 'amber'],
                    'amazon_inventory' => ['label' => 'Amazon Inventory', 'color' => 'amber'],
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form method="POST" action="<?php echo e(route('dashboard.sync.trigger')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="type" value="<?php echo e($type); ?>">
                    <button type="submit"
                            class="w-full border border-<?php echo e($info['color']); ?>-200 bg-<?php echo e($info['color']); ?>-50 hover:bg-<?php echo e($info['color']); ?>-100 text-<?php echo e($info['color']); ?>-700 text-xs font-medium py-2 px-3 rounded-lg transition">
                        ↺ <?php echo e($info['label']); ?>

                    </button>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oddo\resources\views/dashboard/settings.blade.php ENDPATH**/ ?>