<?php $__env->startSection('title', app(\App\Services\SettingsService::class)->appName() . ' — Settings'); ?>
<?php $__env->startSection('page-title', 'Global Settings'); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="mb-5 flex items-center gap-3 bg-emerald-50 border border-emerald-200 text-emerald-700 px-4 py-3 rounded-xl text-sm">
    <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<style>
    .settings-card { background:#fff; border:1px solid #e5e7eb; border-radius:10px; margin-bottom:16px; overflow:hidden; }
    .settings-header { display:inline-flex; align-items:center; gap:8px; margin:20px 20px 0 20px; padding:8px 18px; border-radius:999px; font-size:13px; font-weight:700; color:#fff; cursor:pointer; user-select:none; letter-spacing:0.01em; transition:opacity 0.15s; }
    .settings-header:hover { opacity:0.9; }
    .settings-header .icon { font-size:15px; line-height:1; }
    .settings-header .chevron { margin-left:4px; transition:transform 0.2s; }
    .settings-header.open .chevron { transform:rotate(180deg); }
    .settings-divider { height:1px; background:#f3f4f6; margin:16px 0 0 0; }
    .settings-body { padding:8px 0 20px 0; }
    .settings-row { display:grid; grid-template-columns:180px 1fr; gap:12px; align-items:flex-start; padding:12px 24px; }
    .settings-label { font-size:13px; font-weight:600; color:#1f2937; padding-top:8px; line-height:1.4; }
    .settings-desc { font-size:11px; color:#9ca3af; margin-top:2px; }
    .settings-input { width:100%; border:1px solid #d1d5db; border-radius:6px; padding:7px 11px; font-size:13px; color:#1f2937; background:#fff; outline:none; transition:border-color 0.15s,box-shadow 0.15s; }
    .settings-input:focus { border-color:#6366f1; box-shadow:0 0 0 3px rgba(99,102,241,0.1); }
    select.settings-input { cursor:pointer; }
    textarea.settings-input { resize:vertical; font-family:monospace; font-size:12px; }
    .secret-wrap { display:flex; gap:8px; }
    .secret-wrap .settings-input { font-family:monospace; }
    .reveal-btn { padding:7px 12px; font-size:11px; border:1px solid #d1d5db; border-radius:6px; background:#f9fafb; color:#6b7280; cursor:pointer; white-space:nowrap; transition:background 0.15s; }
    .reveal-btn:hover { background:#f3f4f6; }
    .reveal-btn:disabled { opacity:0.4; cursor:not-allowed; }
    .toggle-wrap { display:flex; align-items:center; gap:10px; padding-top:6px; }
    .toggle-track { position:relative; display:inline-flex; align-items:center; width:44px; height:24px; border-radius:999px; background:#d1d5db; cursor:pointer; transition:background 0.2s; }
    .toggle-track.on { background:#1e293b; }
    .toggle-thumb { position:absolute; left:3px; width:18px; height:18px; border-radius:50%; background:#fff; box-shadow:0 1px 3px rgba(0,0,0,0.2); transition:transform 0.2s; }
    .toggle-track.on .toggle-thumb { transform:translateX(20px); }
    .toggle-label { font-size:13px; color:#6b7280; }
    .save-bar { position:sticky; bottom:0; left:0; right:0; background:rgba(255,255,255,0.95); backdrop-filter:blur(8px); border-top:1px solid #e5e7eb; padding:14px 0; margin-top:8px; display:flex; align-items:center; justify-content:space-between; }
    .save-btn { background:#f97316; color:#fff; font-size:13px; font-weight:700; padding:10px 28px; border-radius:8px; border:none; cursor:pointer; transition:background 0.15s; letter-spacing:0.01em; }
    .save-btn:hover { background:#ea6c00; }
    .erp-pill { display:inline-flex; align-items:center; gap:6px; padding:4px 12px; border-radius:999px; font-size:11px; font-weight:600; border:1.5px solid #d1d5db; cursor:pointer; transition:all 0.15s; background:#fff; color:#6b7280; }
    .erp-pill.selected { background:#1e293b; color:#fff; border-color:#1e293b; }
    .secret-badge { display:inline-flex; align-items:center; gap:3px; font-size:10px; color:#ef4444; background:#fef2f2; border:1px solid #fecaca; padding:1px 6px; border-radius:999px; margin-top:4px; }
</style>

<form method="POST" action="<?php echo e(route('dashboard.settings.update')); ?>" id="settings-form">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <?php
        $sectionOrder = ['general', 'odoo', 'shopify', 'amazon'];
        $sectionConfig = [
            'general' => ['label' => 'Common Settings',  'gradient' => 'linear-gradient(135deg,#f97316,#ef4444)', 'open' => true],
            'odoo'    => ['label' => 'Odoo Settings',     'gradient' => 'linear-gradient(135deg,#7c3aed,#6366f1)', 'open' => false],
            'shopify' => ['label' => 'Shopify Settings',  'gradient' => 'linear-gradient(135deg,#059669,#10b981)', 'open' => false],
            'amazon'  => ['label' => 'Amazon Settings',   'gradient' => 'linear-gradient(135deg,#d97706,#f59e0b)', 'open' => false],
        ];
    ?>

    <?php $__currentLoopData = $sectionOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupKey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $settings = $groups[$groupKey] ?? collect();
            $cfg      = $sectionConfig[$groupKey];
            $domId    = 'section-' . $groupKey;
        ?>

        <div class="settings-card">
            <div class="settings-header <?php echo e($cfg['open'] ? 'open' : ''); ?>"
                 style="background:<?php echo e($cfg['gradient']); ?>"
                 onclick="toggleSection('<?php echo e($domId); ?>', this)">
                <span class="icon"><?php echo e($cfg['open'] ? '−' : '+'); ?></span>
                <?php echo e($cfg['label']); ?>

                <svg class="chevron w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M19 9l-7 7-7-7"/>
                </svg>
            </div>
            <div class="settings-divider"></div>
            <div id="<?php echo e($domId); ?>" class="settings-body" style="<?php echo e($cfg['open'] ? '' : 'display:none'); ?>">
                <?php if($settings->isEmpty()): ?>
                    <div class="px-6 py-6 text-center text-sm text-gray-400">No settings configured.</div>
                <?php else: ?>
                    <?php $__currentLoopData = $settings->sortBy('sort_order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $fieldType    = $setting->field_type ?? 'text';
                        $currentValue = $setting->getDecryptedValue() ?? $setting->default_value ?? '';
                    ?>
                    <div class="settings-row">
                        
                        <div>
                            <div class="settings-label"><?php echo e($setting->label); ?></div>
                            <?php if($setting->description): ?>
                                <div class="settings-desc"><?php echo e($setting->description); ?></div>
                            <?php endif; ?>
                            <?php if($setting->is_secret): ?>
                                <div class="secret-badge">
                                    <svg width="10" height="10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                                    Secret
                                </div>
                            <?php endif; ?>
                        </div>

                        
                        <div>

                            
                            <?php if($setting->key === 'erp_driver'): ?>
                            <div x-data="{ selected: '<?php echo e($currentValue ?: 'odoo'); ?>' }" style="padding-top:4px">
                                <input type="hidden" name="<?php echo e($setting->key); ?>" :value="selected">
                                <div style="display:flex;gap:8px;flex-wrap:wrap">
                                    <?php $__currentLoopData = ['odoo' => '🔗 Odoo', 'sap' => '⚡ SAP', 'netsuite' => '☁️ NetSuite']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $lbl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <button type="button"
                                            @click="selected = '<?php echo e($val); ?>'"
                                            :class="selected === '<?php echo e($val); ?>' ? 'selected' : ''"
                                            class="erp-pill">
                                        <?php echo e($lbl); ?>

                                    </button>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <p style="font-size:11px;color:#9ca3af;margin-top:6px">
                                    Active ERP adapter. Change the <strong>ERP Display Name</strong> above to match.
                                </p>
                            </div>

                            
                            <?php elseif($fieldType === 'toggle'): ?>
                            <div x-data="{ on: <?php echo e(in_array($currentValue, ['1','true','yes','on']) ? 'true' : 'false'); ?> }"
                                 class="toggle-wrap">
                                <div class="toggle-track" :class="on ? 'on' : ''" @click="on = !on">
                                    <div class="toggle-thumb"></div>
                                </div>
                                <span class="toggle-label" x-text="on ? 'Enabled' : 'Disabled'"></span>
                                <input type="hidden" name="<?php echo e($setting->key); ?>" :value="on ? '1' : '0'">
                            </div>

                            
                            <?php elseif($fieldType === 'textarea'): ?>
                            <textarea name="<?php echo e($setting->key); ?>"
                                      rows="3"
                                      placeholder="<?php echo e($setting->default_value); ?>"
                                      class="settings-input"><?php echo e($currentValue); ?></textarea>

                            
                            <?php elseif($fieldType === 'number'): ?>
                            <input type="number"
                                   name="<?php echo e($setting->key); ?>"
                                   value="<?php echo e($currentValue); ?>"
                                   placeholder="<?php echo e($setting->default_value); ?>"
                                   style="width:120px"
                                   class="settings-input">

                            
                            <?php elseif($setting->is_secret): ?>
                            <div x-data="{ revealed: false, loading: false, val: '' }" class="secret-wrap">
                                <input :type="revealed ? 'text' : 'password'"
                                       name="<?php echo e($setting->key); ?>"
                                       :value="revealed ? val : ''"
                                       :placeholder="revealed ? '' : '<?php echo e($setting->getMaskedValue() ?: 'Not set — enter value'); ?>'"
                                       class="settings-input">
                                <?php if(auth()->user()->can('reveal-secrets')): ?>
                                <button type="button" class="reveal-btn"
                                        :disabled="revealed || loading"
                                        @click="loading=true; fetch('<?php echo e(route('dashboard.settings.reveal', $setting)); ?>',{headers:{'X-Requested-With':'XMLHttpRequest','Accept':'application/json'}}).then(r=>r.json()).then(d=>{val=d.value;revealed=true;loading=false}).catch(()=>loading=false)">
                                    <span x-show="!loading && !revealed">Reveal</span>
                                    <span x-show="loading">…</span>
                                    <span x-show="revealed">✓ Shown</span>
                                </button>
                                <?php endif; ?>
                            </div>
                            <div style="font-size:11px;color:#9ca3af;margin-top:4px">Leave blank to keep existing value.</div>

                            
                            <?php else: ?>
                            <input type="text"
                                   name="<?php echo e($setting->key); ?>"
                                   value="<?php echo e($currentValue); ?>"
                                   placeholder="<?php echo e($setting->default_value); ?>"
                                   class="settings-input"
                                   <?php if($setting->key === 'app_name'): ?> style="font-weight:600" <?php endif; ?>>
                            <?php if($setting->key === 'app_name'): ?>
                                <p style="font-size:11px;color:#9ca3af;margin-top:4px">
                                    Used in the browser tab and page header across the whole app.
                                </p>
                            <?php endif; ?>
                            <?php if($setting->key === 'erp_display_name'): ?>
                                <p style="font-size:11px;color:#9ca3af;margin-top:4px">
                                    Replaces "Odoo" wherever ERP labels appear — field config columns, product pages, log messages.
                                </p>
                            <?php endif; ?>
                            <?php endif; ?>

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <?php if(auth()->user()->can('trigger-sync')): ?>
    <div class="settings-card">
        <div class="settings-header"
             style="background:linear-gradient(135deg,#475569,#334155)"
             onclick="toggleSection('section-sync-triggers', this)">
            <span class="icon">+</span>
            Sync Triggers
            <svg class="chevron w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M19 9l-7 7-7-7"/>
            </svg>
        </div>
        <div class="settings-divider"></div>
        <div id="section-sync-triggers" class="settings-body" style="display:none">
            <div style="padding:4px 24px 8px;display:grid;grid-template-columns:repeat(4,1fr);gap:10px">
                <?php $__currentLoopData = [
                    'products'         => ['label' => 'Shopify Products',  'color' => '#6366f1'],
                    'inventory'        => ['label' => 'Shopify Inventory', 'color' => '#6366f1'],
                    'orders'           => ['label' => 'Shopify Orders',    'color' => '#6366f1'],
                    'customers'        => ['label' => 'Customers',         'color' => '#6366f1'],
                    'amazon_products'  => ['label' => 'Amazon Products',   'color' => '#d97706'],
                    'amazon_orders'    => ['label' => 'Amazon Orders',     'color' => '#d97706'],
                    'amazon_inventory' => ['label' => 'Amazon Inventory',  'color' => '#d97706'],
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form method="POST" action="<?php echo e(route('dashboard.sync.trigger')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="type" value="<?php echo e($type); ?>">
                    <button type="submit"
                            style="width:100%;padding:8px 10px;border:1.5px solid <?php echo e($info['color']); ?>30;border-radius:7px;background:<?php echo e($info['color']); ?>10;color:<?php echo e($info['color']); ?>;font-size:12px;font-weight:600;cursor:pointer;transition:background 0.15s"
                            onmouseover="this.style.background='<?php echo e($info['color']); ?>20'"
                            onmouseout="this.style.background='<?php echo e($info['color']); ?>10'">
                        ↺ <?php echo e($info['label']); ?>

                    </button>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    
    <div class="save-bar">
        <p style="font-size:12px;color:#9ca3af">Changes take effect immediately after saving.</p>
        <button type="submit" class="save-btn">Save Changes</button>
    </div>
</form>

<script>
function toggleSection(id, header) {
    const body   = document.getElementById(id);
    const isOpen = body.style.display !== 'none';
    body.style.display = isOpen ? 'none' : 'block';
    header.classList.toggle('open', !isOpen);
    const icon = header.querySelector('.icon');
    if (icon) icon.textContent = isOpen ? '+' : '−';
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oddo\resources\views/dashboard/settings.blade.php ENDPATH**/ ?>