<?php $__env->startSection('title', 'Orders'); ?>
<?php $__env->startSection('page-title', 'Orders Sync'); ?>

<?php $__env->startSection('content'); ?>


<div class="grid grid-cols-3 gap-4 mb-4">
    <?php $__currentLoopData = [
        ['label' => 'Shopify Orders', 'value' => $stats['shopify_total'], 'color' => 'indigo'],
        ['label' => 'Amazon Orders',  'value' => $stats['amazon_total'],  'color' => 'amber'],
        ['label' => 'Synced Today',   'value' => $stats['today'],         'color' => 'green'],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4 flex items-center gap-3">
        <div class="text-2xl font-bold text-<?php echo e($s['color']); ?>-600"><?php echo e(number_format($s['value'])); ?></div>
        <div class="text-sm text-gray-500"><?php echo e($s['label']); ?></div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4 mb-4">
    <form method="GET" class="flex flex-wrap gap-3 items-end">
        <div>
            <label class="block text-xs text-gray-500 mb-1">Search</label>
            <input type="text" name="search" value="<?php echo e($search); ?>"
                   placeholder="Order ID, Shopify name…"
                   class="border border-gray-200 rounded-lg px-3 py-1.5 text-sm w-64 focus:ring-2 focus:ring-indigo-300 outline-none">
        </div>
        <div>
            <label class="block text-xs text-gray-500 mb-1">Channel</label>
            <select name="channel" class="border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-indigo-300 outline-none">
                <option value="all"     <?php echo e($channel === 'all'     ? 'selected' : ''); ?>>All</option>
                <option value="shopify" <?php echo e($channel === 'shopify' ? 'selected' : ''); ?>>Shopify</option>
                <option value="amazon"  <?php echo e($channel === 'amazon'  ? 'selected' : ''); ?>>Amazon</option>
            </select>
        </div>
        <button type="submit" class="bg-indigo-600 text-white px-4 py-1.5 rounded-lg text-sm hover:bg-indigo-700">Filter</button>
        <a href="<?php echo e(route('dashboard.orders')); ?>" class="text-sm text-gray-500 py-1.5">Reset</a>
    </form>
</div>


<div class="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden mb-4">
    <div class="px-5 py-3 border-b border-gray-100">
        <span class="text-sm font-medium text-gray-700"><?php echo e($orders->total()); ?> order mappings</span>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wide">
                <tr>
                    <th class="px-4 py-3 text-left font-medium">Channel</th>
                    <th class="px-4 py-3 text-left font-medium">Odoo Order ID</th>
                    <th class="px-4 py-3 text-left font-medium">External Order</th>
                    <th class="px-4 py-3 text-left font-medium">Order Name / Ref</th>
                    <th class="px-4 py-3 text-left font-medium">Last Synced</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-4 py-3">
                        <?php if(str_starts_with($mapping->entity_type, 'amazon')): ?>
                            <span class="badge bg-amber-100 text-amber-800">Amazon</span>
                        <?php else: ?>
                            <span class="badge bg-indigo-100 text-indigo-800">Shopify</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-3 font-mono text-xs">
                        <span class="bg-gray-100 px-1.5 py-0.5 rounded text-gray-700">#<?php echo e($mapping->odoo_id); ?></span>
                    </td>
                    <td class="px-4 py-3 font-mono text-xs text-gray-600">
                        <?php echo e($mapping->shopify_id); ?>

                    </td>
                    <td class="px-4 py-3 text-gray-700 font-medium">
                        <?php echo e($mapping->shopify_handle ?: '—'); ?>

                    </td>
                    <td class="px-4 py-3 text-xs text-gray-400">
                        <?php echo e($mapping->last_synced_at?->diffForHumans() ?? 'Never'); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="px-4 py-12 text-center text-gray-400">
                        No order mappings yet. Orders sync when Shopify webhooks are received or Amazon is polled.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="px-5 py-3 border-t border-gray-100"><?php echo e($orders->links()); ?></div>
</div>


<div class="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
    <h3 class="text-sm font-semibold text-gray-700 mb-3">Recent Order Sync Activity</h3>
    <?php echo $__env->make('dashboard._log-rows', ['logs' => $recentLogs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oddo\resources\views/dashboard/orders.blade.php ENDPATH**/ ?>