<?php $__env->startSection('title', 'Sync Logs'); ?>
<?php $__env->startSection('page-title', 'Sync Logs'); ?>

<?php $__env->startSection('content'); ?>


<div class="flex flex-wrap gap-2 mb-4">
    <?php $__currentLoopData = ['success' => 'green', 'failed' => 'red', 'pending' => 'yellow', 'processing' => 'blue', 'skipped' => 'gray']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('dashboard.logs', array_merge(request()->query(), ['status' => $s]))); ?>"
       class="badge bg-<?php echo e($c); ?>-100 text-<?php echo e($c); ?>-800 text-xs py-1 px-3 hover:ring-2 hover:ring-<?php echo e($c); ?>-300 <?php echo e($status === $s ? 'ring-2 ring-'.$c.'-400' : ''); ?>">
        <?php echo e(ucfirst($s)); ?> <?php echo e($summary[$s] ?? 0); ?>

    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($status): ?>
    <a href="<?php echo e(route('dashboard.logs', array_diff_key(request()->query(), ['status' => '']))); ?>"
       class="badge bg-gray-100 text-gray-600 text-xs py-1 px-3 hover:bg-gray-200">× Clear filter</a>
    <?php endif; ?>
</div>


<div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4 mb-4">
    <form method="GET" class="flex flex-wrap gap-3 items-end">
        <div>
            <label class="block text-xs text-gray-500 mb-1">Search</label>
            <input type="text" name="search" value="<?php echo e($search); ?>" placeholder="Entity ID, error text…"
                   class="border border-gray-200 rounded-lg px-3 py-1.5 text-sm w-52 focus:ring-2 focus:ring-indigo-300 outline-none">
        </div>
        <div>
            <label class="block text-xs text-gray-500 mb-1">Direction</label>
            <select name="direction" class="border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-indigo-300 outline-none">
                <option value="">All</option>
                <option value="odoo_to_shopify" <?php echo e($direction === 'odoo_to_shopify' ? 'selected' : ''); ?>>Odoo → Shopify/Amazon</option>
                <option value="shopify_to_odoo" <?php echo e($direction === 'shopify_to_odoo' ? 'selected' : ''); ?>>Shopify/Amazon → Odoo</option>
            </select>
        </div>
        <div>
            <label class="block text-xs text-gray-500 mb-1">Entity Type</label>
            <select name="entity_type" class="border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-indigo-300 outline-none">
                <option value="">All</option>
                <?php $__currentLoopData = $entityTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($type); ?>" <?php echo e($entityType === $type ? 'selected' : ''); ?>><?php echo e($type); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label class="block text-xs text-gray-500 mb-1">Status</label>
            <select name="status" class="border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-indigo-300 outline-none">
                <option value="">All</option>
                <?php $__currentLoopData = ['success', 'failed', 'pending', 'processing', 'skipped']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($s); ?>" <?php echo e($status === $s ? 'selected' : ''); ?>><?php echo e(ucfirst($s)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label class="block text-xs text-gray-500 mb-1">From</label>
            <input type="date" name="date_from" value="<?php echo e($dateFrom); ?>"
                   class="border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-indigo-300 outline-none">
        </div>
        <div>
            <label class="block text-xs text-gray-500 mb-1">To</label>
            <input type="date" name="date_to" value="<?php echo e($dateTo); ?>"
                   class="border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-indigo-300 outline-none">
        </div>
        <button type="submit" class="bg-indigo-600 text-white px-4 py-1.5 rounded-lg text-sm hover:bg-indigo-700">Filter</button>
        <a href="<?php echo e(route('dashboard.logs')); ?>" class="text-sm text-gray-500 py-1.5">Reset</a>
    </form>
</div>


<div class="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
    <div class="px-5 py-3 border-b border-gray-100">
        <span class="text-sm font-medium text-gray-700"><?php echo e($logs->total()); ?> entries</span>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wide">
                <tr>
                    <th class="px-4 py-3 text-left font-medium">Direction</th>
                    <th class="px-4 py-3 text-left font-medium">Entity Type</th>
                    <th class="px-4 py-3 text-left font-medium">Entity ID</th>
                    <th class="px-4 py-3 text-left font-medium">Action</th>
                    <th class="px-4 py-3 text-left font-medium">Status</th>
                    <th class="px-4 py-3 text-left font-medium">Attempts</th>
                    <th class="px-4 py-3 text-left font-medium">Error</th>
                    <th class="px-4 py-3 text-left font-medium">Timestamp</th>
                    <th class="px-4 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 <?php echo e($log->status === 'failed' ? 'bg-red-50/40' : ''); ?>">
                    <td class="px-4 py-2.5">
                        <?php if($log->direction === 'odoo_to_shopify'): ?>
                            <span class="badge bg-blue-100 text-blue-700 text-xs">Odoo → Out</span>
                        <?php else: ?>
                            <span class="badge bg-purple-100 text-purple-700 text-xs">In → Odoo</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-2.5"><span class="badge bg-gray-100 text-gray-600 text-xs"><?php echo e($log->entity_type); ?></span></td>
                    <td class="px-4 py-2.5 font-mono text-xs text-gray-700">#<?php echo e($log->entity_id); ?></td>
                    <td class="px-4 py-2.5 text-gray-600 capitalize text-xs"><?php echo e($log->action); ?></td>
                    <td class="px-4 py-2.5">
                        <?php $colors = ['success'=>'green','failed'=>'red','pending'=>'yellow','processing'=>'blue','skipped'=>'gray']; $c = $colors[$log->status] ?? 'gray'; ?>
                        <span class="badge bg-<?php echo e($c); ?>-100 text-<?php echo e($c); ?>-700 text-xs"><?php echo e($log->status); ?></span>
                    </td>
                    <td class="px-4 py-2.5 text-center text-xs text-gray-500"><?php echo e($log->attempts); ?></td>
                    <td class="px-4 py-2.5 text-xs text-red-500 max-w-xs">
                        <span class="truncate block" style="max-width:200px" title="<?php echo e($log->error_message); ?>">
                            <?php echo e(Str::limit($log->error_message, 60)); ?>

                        </span>
                    </td>
                    <td class="px-4 py-2.5 text-xs text-gray-400 whitespace-nowrap">
                        <?php echo e($log->created_at->format('M j, H:i')); ?>

                    </td>
                    <td class="px-4 py-2.5">
                        <a href="<?php echo e(route('dashboard.logs.show', $log)); ?>"
                           class="text-xs text-indigo-600 hover:underline whitespace-nowrap">Details →</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="9" class="px-4 py-12 text-center text-gray-400">No logs match your filters.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="px-5 py-3 border-t border-gray-100"><?php echo e($logs->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oddo\resources\views/dashboard/logs.blade.php ENDPATH**/ ?>