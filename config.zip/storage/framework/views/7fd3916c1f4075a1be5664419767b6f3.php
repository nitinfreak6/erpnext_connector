<?php $__env->startSection('title', $user->exists ? 'Edit User' : 'Add User'); ?>
<?php $__env->startSection('page-title', $user->exists ? 'Edit User' : 'Add User'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-lg">
    <div class="mb-4">
        <a href="<?php echo e(route('dashboard.users.index')); ?>" class="text-sm text-indigo-600 hover:underline">← Back to users</a>
    </div>

    <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-6">
        <?php if($errors->any()): ?>
        <div class="mb-4 bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 text-sm">
            <ul class="list-disc list-inside space-y-1">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        <form method="POST"
              action="<?php echo e($user->exists ? route('dashboard.users.update', $user) : route('dashboard.users.store')); ?>"
              class="space-y-5">
            <?php echo csrf_field(); ?>
            <?php if($user->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" required
                       class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-300 outline-none">
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" required
                       class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-300 outline-none">
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    Password <?php echo e($user->exists ? '(leave blank to keep current)' : ''); ?>

                </label>
                <input type="password" name="password" <?php echo e($user->exists ? '' : 'required'); ?>

                       class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-300 outline-none">
            </div>

            <?php if($user->exists || true): ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Confirm Password</label>
                <input type="password" name="password_confirmation"
                       class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-300 outline-none">
            </div>
            <?php endif; ?>

            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Role</label>
                <select name="role" required
                        class="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-300 outline-none">
                    <option value="viewer"  <?php echo e(old('role', $user->role) === 'viewer'  ? 'selected' : ''); ?>>Viewer — read-only access</option>
                    <option value="manager" <?php echo e(old('role', $user->role) === 'manager' ? 'selected' : ''); ?>>Manager — can trigger syncs</option>
                    <option value="admin"   <?php echo e(old('role', $user->role) === 'admin'   ? 'selected' : ''); ?>>Admin — full access including API settings</option>
                </select>
            </div>

            <div class="flex items-center gap-2">
                <input type="checkbox" name="is_active" id="is_active" value="1"
                       <?php echo e(old('is_active', $user->is_active ?? true) ? 'checked' : ''); ?>

                       class="h-4 w-4 text-indigo-600 rounded border-gray-300">
                <label for="is_active" class="text-sm text-gray-700">Active (can log in)</label>
            </div>

            <div class="flex gap-3 pt-2">
                <button type="submit"
                        class="bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium px-5 py-2 rounded-lg transition">
                    <?php echo e($user->exists ? 'Update User' : 'Create User'); ?>

                </button>
                <a href="<?php echo e(route('dashboard.users.index')); ?>"
                   class="border border-gray-200 text-gray-600 text-sm px-5 py-2 rounded-lg hover:bg-gray-50 transition">
                    Cancel
                </a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oddo\resources\views/dashboard/users/form.blade.php ENDPATH**/ ?>