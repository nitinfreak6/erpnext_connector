<?php $__env->startSection('title', 'Webhooks'); ?>
<?php $__env->startSection('page-title', 'Webhook Logs'); ?>

<?php $__env->startSection('content'); ?>


<div class="grid grid-cols-4 gap-4 mb-4">
    <?php $__currentLoopData = [
        ['label' => 'Total',     'value' => $summary['total'],     'color' => 'gray'],
        ['label' => 'Processed', 'value' => $summary['processed'], 'color' => 'green'],
        ['label' => 'Pending',   'value' => $summary['pending'],   'color' => 'yellow'],
        ['label' => 'Errors',    'value' => $summary['errors'],    'color' => 'red'],
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4 flex items-center gap-3">
        <div class="text-2xl font-bold text-<?php echo e($s['color']); ?>-600"><?php echo e(number_format($s['value'])); ?></div>
        <div class="text-sm text-gray-500"><?php echo e($s['label']); ?></div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="bg-white rounded-xl border border-gray-100 shadow-sm p-4 mb-4">
    <form method="GET" class="flex flex-wrap gap-3 items-end">
        <div>
            <label class="block text-xs text-gray-500 mb-1">Search</label>
            <input type="text" name="search" value="<?php echo e($search); ?>" placeholder="Webhook ID, shop domain…"
                   class="border border-gray-200 rounded-lg px-3 py-1.5 text-sm w-56 focus:ring-2 focus:ring-indigo-300 outline-none">
        </div>
        <div>
            <label class="block text-xs text-gray-500 mb-1">Topic</label>
            <select name="topic" class="border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-indigo-300 outline-none">
                <option value="">All Topics</option>
                <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($t); ?>" <?php echo e($topic === $t ? 'selected' : ''); ?>><?php echo e($t); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label class="block text-xs text-gray-500 mb-1">Status</label>
            <select name="processed" class="border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-indigo-300 outline-none">
                <option value="">All</option>
                <option value="1" <?php echo e($processed === '1' ? 'selected' : ''); ?>>Processed</option>
                <option value="0" <?php echo e($processed === '0' ? 'selected' : ''); ?>>Pending</option>
            </select>
        </div>
        <div>
            <label class="block text-xs text-gray-500 mb-1">From Date</label>
            <input type="date" name="date_from" value="<?php echo e(request('date_from')); ?>"
                   class="border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-indigo-300 outline-none">
        </div>
        <button type="submit" class="bg-indigo-600 text-white px-4 py-1.5 rounded-lg text-sm hover:bg-indigo-700">Filter</button>
        <a href="<?php echo e(route('dashboard.webhooks')); ?>" class="text-sm text-gray-500 py-1.5">Reset</a>
    </form>
</div>


<div class="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
    <div class="px-5 py-3 border-b border-gray-100">
        <span class="text-sm font-medium text-gray-700"><?php echo e($webhooks->total()); ?> webhooks</span>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wide">
                <tr>
                    <th class="px-4 py-3 text-left font-medium">Topic</th>
                    <th class="px-4 py-3 text-left font-medium">Shopify Webhook ID</th>
                    <th class="px-4 py-3 text-left font-medium">Shop Domain</th>
                    <th class="px-4 py-3 text-left font-medium">HMAC</th>
                    <th class="px-4 py-3 text-left font-medium">Status</th>
                    <th class="px-4 py-3 text-left font-medium">Error</th>
                    <th class="px-4 py-3 text-left font-medium">Received</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php $__empty_1 = true; $__currentLoopData = $webhooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 <?php echo e($wh->processing_error ? 'bg-red-50/30' : ''); ?>"
                    x-data="{ expanded: false }">
                    <td class="px-4 py-2.5">
                        <span class="badge bg-violet-100 text-violet-700 text-xs"><?php echo e($wh->topic); ?></span>
                    </td>
                    <td class="px-4 py-2.5 font-mono text-xs text-gray-600">
                        <?php echo e(Str::limit($wh->shopify_webhook_id, 24)); ?>

                    </td>
                    <td class="px-4 py-2.5 text-xs text-gray-600"><?php echo e($wh->shop_domain); ?></td>
                    <td class="px-4 py-2.5">
                        <?php if($wh->hmac_valid): ?>
                            <span class="text-green-600 text-xs">✓ Valid</span>
                        <?php else: ?>
                            <span class="text-red-600 text-xs">✗ Invalid</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-2.5">
                        <?php if($wh->processed): ?>
                            <span class="badge bg-green-100 text-green-700 text-xs">processed</span>
                        <?php elseif($wh->processing_error): ?>
                            <span class="badge bg-red-100 text-red-700 text-xs">failed</span>
                        <?php else: ?>
                            <span class="badge bg-yellow-100 text-yellow-700 text-xs">pending</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-2.5 text-xs text-red-500 max-w-xs">
                        <span class="truncate block" style="max-width:180px" title="<?php echo e($wh->processing_error); ?>">
                            <?php echo e(Str::limit($wh->processing_error, 50)); ?>

                        </span>
                    </td>
                    <td class="px-4 py-2.5 text-xs text-gray-400 whitespace-nowrap">
                        <?php echo e($wh->created_at->format('M j, H:i:s')); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="px-4 py-12 text-center text-gray-400">No webhooks received yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="px-5 py-3 border-t border-gray-100"><?php echo e($webhooks->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\oddo\resources\views/dashboard/webhooks.blade.php ENDPATH**/ ?>