<?php

namespace App\Console\Commands;

use App\Jobs\Odoo\FetchOdooProductsJob;
use App\Models\SyncQueueState;
use App\Services\Odoo\OdooProductService;
use Illuminate\Console\Command;

class SyncProducts extends Command
{
    protected $signature = 'sync:products
                            {--full    : Ignore write_date cursor and sync ALL active products}
                            {--limit=0 : Max number of products to process (0 = unlimited)}
                            {--dry-run : Print products without dispatching jobs}
                            {--status  : Show current cursor and queue state, then exit}';

    protected $description = 'Sync Odoo products → Shopify (incremental by default, --full to resync all)';

    public function handle(OdooProductService $odooProducts): int
    {
        // ── Status report ────────────────────────────────────────────────
        if ($this->option('status')) {
            $state = SyncQueueState::forType('products');

            $this->line('');
            $this->table(
                ['Field', 'Value'],
                [
                    ['ERP driver',             'odoo'],
                    ['Last write_date cursor',  $state->last_odoo_write_date ?? '<none — full sync needed>'],
                    ['Last polled',             $state->last_poll_at?->diffForHumans() ?? 'never'],
                    ['Currently running',       $state->is_running ? 'YES' : 'no'],
                    ['Run started at',          $state->run_started_at?->toDateTimeString() ?? '-'],
                    ['Last error',              $state->notes ?? '-'],
                ]
            );
            $this->line('');

            return self::SUCCESS;
        }

        $full   = (bool) $this->option('full');
        $limit  = (int)  $this->option('limit');
        $dryRun = (bool) $this->option('dry-run');

        $this->info('Starting product sync' . ($full ? ' (FULL)' : ' (incremental)') . ($dryRun ? ' [DRY RUN]' : '') . '...');

        // ── Dry run ──────────────────────────────────────────────────────
        if ($dryRun) {
            $state    = SyncQueueState::forType('products');
            $cursor   = $state->last_odoo_write_date;

            if ($full || !$cursor) {
                $this->line('Mode: full — fetching all active products');
                $products = $odooProducts->getAllActive(0, $limit ?: 20);
            } else {
                $this->line("Mode: incremental — products modified since {$cursor}");
                $products = $odooProducts->getModifiedSince($cursor);
            }

            if (empty($products)) {
                $this->info('Nothing to sync.');
                return self::SUCCESS;
            }

            $this->table(['ID', 'Name', 'Write Date'], array_map(fn($p) => [
                $p['id'], mb_strimwidth($p['name'] ?? '', 0, 50, '…'), $p['write_date'] ?? '',
            ], $products));

            $this->info(count($products) . ' product(s) would be synced.');
            return self::SUCCESS;
        }

        // ── Dispatch ─────────────────────────────────────────────────────
        // fullSync=true  → job calls getAllActive() (ignores cursor)
        // fullSync=false → job calls getModifiedSince(cursor) — only changed products
        FetchOdooProductsJob::dispatch(
            fullSync: $full || $limit > 0,
            shopify:  true,
            amazon:   false,
        );

        $this->info('FetchOdooProductsJob dispatched to queue [sync].');
        $this->line("Run <info>php artisan queue:work --queue=sync</info> to process.");

        return self::SUCCESS;
    }
}
