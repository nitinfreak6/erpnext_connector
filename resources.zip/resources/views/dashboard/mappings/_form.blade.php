{{-- Shared form fields for Add and Edit mapping modals --}}
{{-- Used with x-model bound to Alpine form object --}}

{{-- Row 1: ERP Save ID + Ecom Save ID --}}
<div class="grid grid-cols-2 gap-4">
    <div>
        <label class="block text-xs font-medium text-gray-600 mb-1">
            {{ $erpDisplayName }} Save ID <span class="text-red-500">*</span>
        </label>
        <select name="channel" :value="form.channel" @change="form.channel = $event.target.value"
                class="w-full text-sm border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-300 outline-none">
            <option value="shopify">{{ $ecomDisplayName }}</option>
            <option value="amazon">Amazon</option>
            <option value="both">Both</option>
        </select>
    </div>
    <div>
        <label class="block text-xs font-medium text-gray-600 mb-1">
            {{ $ecomDisplayName }} Save ID <span class="text-red-500">*</span>
        </label>
        <input type="text" name="external_id" :value="form.external_id" @input="form.external_id = $event.target.value"
               placeholder="e.g. 69188747343"
               class="w-full text-sm border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-300 outline-none">
    </div>
</div>

{{-- Row 2: ERP Field + Ecom Field --}}
<div class="grid grid-cols-2 gap-4">
    <div>
        <label class="block text-xs font-medium text-gray-600 mb-1">{{ $erpDisplayName }} Field</label>
        <input type="text" name="odoo_id" :value="form.odoo_id" @input="form.odoo_id = $event.target.value"
               placeholder="e.g. 5 or field name"
               class="w-full text-sm border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-300 outline-none">
    </div>
    <div>
        <label class="block text-xs font-medium text-gray-600 mb-1">{{ $erpDisplayName }} Label</label>
        <input type="text" name="odoo_label" :value="form.odoo_label" @input="form.odoo_label = $event.target.value"
               placeholder="e.g. WH/Stock"
               class="w-full text-sm border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-300 outline-none">
    </div>
</div>

{{-- Row 3: ERP Value Field + Ecom Value Field --}}
<div class="grid grid-cols-2 gap-4">
    <div>
        <label class="block text-xs font-medium text-gray-600 mb-1">{{ $erpDisplayName }} Value Field</label>
        <input type="text" name="odoo_value_field" :value="form.odoo_value_field" @input="form.odoo_value_field = $event.target.value"
               placeholder="e.g. name"
               class="w-full text-sm border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-300 outline-none">
    </div>
    <div>
        <label class="block text-xs font-medium text-gray-600 mb-1">{{ $ecomDisplayName }} Field</label>
        <input type="text" name="external_label" :value="form.external_label" @input="form.external_label = $event.target.value"
               placeholder="e.g. Main Warehouse"
               class="w-full text-sm border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-300 outline-none">
    </div>
</div>

{{-- Row 4: Ecom Value Field + Default Value --}}
<div class="grid grid-cols-2 gap-4">
    <div>
        <label class="block text-xs font-medium text-gray-600 mb-1">{{ $ecomDisplayName }} Value Field</label>
        <input type="text" name="external_value_field" :value="form.external_value_field" @input="form.external_value_field = $event.target.value"
               placeholder="e.g. id"
               class="w-full text-sm border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-300 outline-none">
    </div>
    <div>
        <label class="block text-xs font-medium text-gray-600 mb-1">Default Value</label>
        <input type="text" name="default_value" :value="form.default_value" @input="form.default_value = $event.target.value"
               placeholder="Fallback if no match"
               class="w-full text-sm border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-300 outline-none">
    </div>
</div>

{{-- Row 5: Min Length + Max Length --}}
<div class="grid grid-cols-2 gap-4">
    <div>
        <label class="block text-xs font-medium text-gray-600 mb-1">Min Length (Prefix Value)</label>
        <input type="text" name="min_length" :value="form.min_length" @input="form.min_length = $event.target.value"
               placeholder="e.g. 3"
               class="w-full text-sm border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-300 outline-none">
    </div>
    <div>
        <label class="block text-xs font-medium text-gray-600 mb-1">Max Length</label>
        <input type="text" name="max_length" :value="form.max_length" @input="form.max_length = $event.target.value"
               placeholder="e.g. 255"
               class="w-full text-sm border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-300 outline-none">
    </div>
</div>

{{-- Active toggle --}}
<label class="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
    <input type="checkbox" name="is_active" value="1"
           :checked="form.is_active"
           @change="form.is_active = $event.target.checked"
           class="rounded text-indigo-600">
    Active
</label>